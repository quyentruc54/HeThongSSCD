﻿namespace NovaAlert.Communication.ATModem
{
    public enum eModemState
    {
        COMMAND_STATE,
        ONLINE_COMMAND_STATE,
        ONLINE_DATA_STATE
    }
}
