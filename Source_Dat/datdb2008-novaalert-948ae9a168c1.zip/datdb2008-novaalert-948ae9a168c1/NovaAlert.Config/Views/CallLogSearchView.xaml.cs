﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for CallLogSearchView.xaml
    /// </summary>
    public partial class CallLogSearchView : UserControl
    {
        public CallLogSearchView()
        {
            InitializeComponent();            
        }
    }
}
