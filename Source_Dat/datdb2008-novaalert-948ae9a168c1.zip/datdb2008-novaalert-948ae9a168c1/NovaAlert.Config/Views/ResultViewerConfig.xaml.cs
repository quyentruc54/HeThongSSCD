﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for ResultViewerConfig.xaml
    /// </summary>
    public partial class ResultViewerConfig : UserControl
    {
        public ResultViewerConfig()
        {
            InitializeComponent();
        }
    }
}
