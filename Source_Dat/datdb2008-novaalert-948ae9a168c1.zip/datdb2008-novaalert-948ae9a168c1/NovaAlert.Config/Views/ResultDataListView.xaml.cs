﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for ResultDataListView.xaml
    /// </summary>
    public partial class ResultDataListView : UserControl
    {
        public ResultDataListView()
        {
            InitializeComponent();
        }
    }
}
