﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for ResultDataListView_CCPK.xaml
    /// </summary>
    public partial class ResultDataListView_CCPK : UserControl
    {
        public ResultDataListView_CCPK()
        {
            InitializeComponent();
        }
    }
}
