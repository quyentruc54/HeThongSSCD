﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for AlertResultListViewCtrl.xaml
    /// </summary>
    public partial class AlertResultListViewCtrl : UserControl
    {
        public AlertResultListViewCtrl()
        {
            InitializeComponent();
        }
    }
}
