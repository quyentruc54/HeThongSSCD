﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for RadioTimeListView.xaml
    /// </summary>
    public partial class RadioTimeListView : UserControl
    {
        public RadioTimeListView()
        {
            InitializeComponent();
        }
    }
}
