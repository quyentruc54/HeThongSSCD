﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for ClientSettingView.xaml
    /// </summary>
    public partial class ClientSettingView : UserControl
    {
        public ClientSettingView()
        {
            InitializeComponent();
        }
    }
}
