﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for AlarmListView.xaml
    /// </summary>
    public partial class AlarmListView : UserControl
    {
        public AlarmListView()
        {
            InitializeComponent();
        }
    }
}
