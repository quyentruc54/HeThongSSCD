﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for DisplayDataView.xaml
    /// </summary>
    public partial class DisplayDataView : UserControl
    {
        public DisplayDataView()
        {
            InitializeComponent();
        }
    }
}
