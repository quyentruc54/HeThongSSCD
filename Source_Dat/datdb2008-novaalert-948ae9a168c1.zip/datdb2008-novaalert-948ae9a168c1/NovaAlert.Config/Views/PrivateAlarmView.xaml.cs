﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for PrivateAlarmView.xaml
    /// </summary>
    public partial class PrivateAlarmView : UserControl
    {
        public PrivateAlarmView()
        {
            InitializeComponent();
        }
    }
}
