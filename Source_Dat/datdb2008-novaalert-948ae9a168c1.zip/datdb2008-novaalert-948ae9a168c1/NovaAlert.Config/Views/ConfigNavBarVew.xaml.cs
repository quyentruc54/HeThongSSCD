﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for ConfigNavBarVew.xaml
    /// </summary>
    public partial class ConfigNavBarVew : UserControl
    {
        public ConfigNavBarVew()
        {
            InitializeComponent();            
        }
    }
}
