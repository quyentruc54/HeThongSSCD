﻿using System.Windows.Controls;

namespace NovaAlert.Config.Views
{
    /// <summary>
    /// Interaction logic for SearchLogView.xaml
    /// </summary>
    public partial class SearchLogView : UserControl
    {
        public SearchLogView()
        {
            InitializeComponent();
        }
    }
}
