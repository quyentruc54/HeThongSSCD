﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace NovaAlert.Gui
{
    /// <summary>
    /// Interaction logic for AlertControlView.xaml
    /// </summary>
    public partial class AlertControlView : UserControl
    {
        public AlertControlView()
        {
            InitializeComponent();
        }
    }
}
