﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace NovaAlert.Gui
{
    /// <summary>
    /// Interaction logic for AlertOptionView.xaml
    /// </summary>
    public partial class AlertOptionView : UserControl
    {
        public AlertOptionView()
        {
            InitializeComponent();
        }
    }
}
