﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace NovaAlert.Gui
{
    /// <summary>
    /// Interaction logic for AlertDivOptionView2.xaml
    /// </summary>
    public partial class AlertOptionView2 : UserControl
    {
        public AlertOptionView2()
        {
            InitializeComponent();
        }
    }
}
