﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace NovaAlert.Gui
{
    /// <summary>
    /// Interaction logic for AppInfoView.xaml
    /// </summary>
    public partial class AppInfoView : UserControl
    {
        public AppInfoView()
        {
            InitializeComponent();
        }
    }
}
