﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Controls;

namespace NovaAlert.Gui
{
    /// <summary>
    /// Interaction logic for VolumnControlView.xaml
    /// </summary>
    public partial class VolumnControlView : UserControl
    {
        public VolumnControlView()
        {
            InitializeComponent();
        }
    }
}
