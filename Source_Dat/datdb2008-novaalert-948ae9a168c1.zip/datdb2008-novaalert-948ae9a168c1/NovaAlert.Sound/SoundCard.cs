﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NovaAlert.Sound
{
    //public class SoundCard: IDisposable
    //{
    //    public SoundChannel LeftChannel { get; private set; }
    //    public SoundChannel RightChannel { get; private set; }

    //    public SoundCard(IntPtr owner, int devId)
    //    {
    //        this.LeftChannel = new SoundChannel(owner, devId, eSpeakerPan.Left);
    //        this.RightChannel = new SoundChannel(owner, devId, eSpeakerPan.Right);
    //    }

    //    public void Dispose()
    //    {
    //        this.LeftChannel.Dispose();
    //        this.RightChannel.Dispose();
    //    }
    //}
}
