﻿namespace NovaAlert.Entities
{
    public interface ISwitchAddress
    {
        string Name { get; }
        byte Address { get; }
    }
}
