﻿namespace NovaAlert.Entities.Enums
{
    public enum eAlertMode
    {
        Call, Transfer
    }
}
