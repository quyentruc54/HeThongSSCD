﻿namespace NovaAlert.Entities
{
    public enum ePOStatus
    {
        OnHook = 1,
        OffHook = 0
    }
}
