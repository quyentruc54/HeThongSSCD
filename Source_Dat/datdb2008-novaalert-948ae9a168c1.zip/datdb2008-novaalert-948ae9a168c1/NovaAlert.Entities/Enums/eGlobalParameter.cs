﻿namespace NovaAlert.Entities
{
    public enum eGlobalParameter
    {
        RestrictedAreaCode,
        OfficeName,
        Menu_DisplayConfig_Visible,
        Menu_CCPK_Visible,
        ShowTSL,
        TSL_PrepareTries,
        TSL_ReceiveTries
    }
}
