﻿namespace NovaAlert.Entities
{
    public enum eVolumn: byte
    {
        Volumn_0 = 0,
        Volumn_1 = 1,
        Volumn_2 = 2,
        Volumn_3 = 3,
        Volumn_4 = 4,
        Volumn_5 = 5,
        Volumn_6 = 6,
        Volumn_7 = 7,
        Volumn_8 = 8,
        Volumn_9 = 9
    }
}
