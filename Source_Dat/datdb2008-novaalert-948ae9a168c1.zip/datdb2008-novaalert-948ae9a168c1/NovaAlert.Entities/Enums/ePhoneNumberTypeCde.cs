﻿namespace NovaAlert.Entities
{
    public enum ePhoneNumberTypeCde
    {
        Army = 1,
        Civil = 2,
        Mobile = 3
    }
}
