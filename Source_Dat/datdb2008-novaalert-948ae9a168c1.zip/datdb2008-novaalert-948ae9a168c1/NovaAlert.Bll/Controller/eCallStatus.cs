﻿namespace NovaAlert.Bll.Controller
{
    public enum eCallStatus
    {
        Created,
        Dialed,
        Connected,
        OnHold
    }
}
