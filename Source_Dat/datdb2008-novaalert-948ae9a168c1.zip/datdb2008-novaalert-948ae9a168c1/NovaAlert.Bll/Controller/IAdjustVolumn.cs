﻿using NovaAlert.Entities;

namespace NovaAlert.Bll.Controller
{
    public interface IAdjustVolumn
    {
        eVolumn Volumn { get; set; }
    }
}
